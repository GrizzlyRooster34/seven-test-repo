
// sensor-bridge.ts
import { execSync } from "child_process";

export function getBatteryStatus() {
  const output = execSync("termux-battery-status").toString();
  return JSON.parse(output);
}

export function getLocation() {
  const output = execSync("termux-location").toString();
  return JSON.parse(output);
}

export function getAmbientLight() {
  const output = execSync("termux-sensor -s light -n 1").toString();
  return output; // Parsing logic can be added here
}

export function getSensorData() {
  return {
    battery: getBatteryStatus(),
    location: getLocation(),
    light: getAmbientLight()
  };
}
